#c=list_add*3
#newlist = [expression for item in iterable if condition == True]

#list_add=["Hassan","Ambreen","Aun Ali","Batool","Tauheed","Danish","Batool","Qaseem","Maaz"]
#list_add.insert(1,"Hasan Raza")
#list_add[2]="Ali"
#list_add.clear()
#a=[]
a="Hello"
print(list(a))
#list_extend=[1.1,2,3]

#list_add.extend(list_extend)
#print(list_add)
#list_to_be_removed=["Tauheed","Ambreen","Danish"]
#list_final=[news for news in list_add if news not in list_to_be_removed]
#print(list_final)
#print(len(c))
#print(list_final)


#for i in list_add:
#    print(i)




'''list_add=["Hassan","Ambreen","Aun Ali","Batool","Tauheed","Danish","Batool","Qaseem","Maaz"]
list_to_be_removed=["Tauheed","Ambreen","Danish"]
empty=[] 
for students in list_add:
    if students not in list_to_be_removed:
        empty.append(students)
print(empty)'''
        