#a=[1,2,3,"Apple","banana",242.323]
#print(type(a[5]))
a=["Hassan","Aun Ali","Batool","Danish","Batool","Qaseem","Maaz"]
#b=[2,3,5,7,9,9,6,43,2,2]
#b.sort()
#print(b)
#print(a[5:])
#a.append("Tariq")
#b=["Tariq","Saqib"]
#c=a+b
#print(a.sort(reverse=False))
#print(c)
#c=a*3
#c.sort()
#count=c.count("Batool")
#print(count)
#c=a.pop()
c=a*10
c.remove("Hassan")
print(c)

#
#a.append(b)
#del b


#b.remove("Saqib","Tariq")
#print(a)

#a.append(b)
#print(a)