'''a=input("Enter").lower()
if(a=='HASAN'):
    print('hello hasan')
elif(a=='ALI'):
    print('Hello ali')
elif(a=='akbar'):
    print('Hello AKBAR')

else:
    print('Kcuh nahi ha')
#varibale[start:end:step]'''





#a="My name is Hasan and i am Hassan"
#print(a)

#print(a.endswith('n'))

#print(a.replace(a,"Qaseem"))
#a=10

#print(a<9)





