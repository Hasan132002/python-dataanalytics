a=[["Hasan","Adil","Qaseem","Iqra"],
   ["Hasan","Adil","Qaseem","Iqra"],
   ["Hasan","Adil","Qaseem","Iqra"],["Hasan","Adil","Qaseem","Iqra"]
   ,["Hasan","Adil","Qaseem","Iqra"]]
print(a)