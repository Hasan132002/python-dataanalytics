a=eval(input("Enter :"))
if(a!=80):
    print("A+")
else:
    print("Necha aya ha grade")
    
    
#==,!=,>,<,>=,<=