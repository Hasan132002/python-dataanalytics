name="Hasan"
list_add=["Hassan","Ambreen","Aun Ali","Batool","Tauheed","Danish","Batool","Qaseem","Maaz"]

father_name="Raza"
a={"Name":name,
   "Father_name":father_name,
   "Mother_name":"Ammi",
   "brother_name" :"Chota bhai",
   "friends":["Hassan","Ambreen","Aun Ali","Batool","Tauheed","Danish","Batool","Qaseem","Maaz"],
   }
print(a["friends"][0])

