name="Programming Fundmentals 101"
a=50
b=2
multiple=a*b
addition=a+b
subtraction=a-b
division=a//b
print("---------------------------------------------------------------------")

print("Addition : ",addition ,"\n Subtraction :",subtraction)
print("---------------------------------------------------------------------")

